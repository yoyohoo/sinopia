export function getEnvConfig() {
    let { config } = CONFIG_SERVICE;
    return config;
}