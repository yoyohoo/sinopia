var dev_config = {
    "ENV": "prod",
    "REST_URL": "http://10.25.1.333"
}
exports.config = dev_config;