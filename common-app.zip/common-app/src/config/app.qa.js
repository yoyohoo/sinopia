var qa_config = {
    "ENV": "qa",
    "REST_URL": "http://10.25.1.222"
}
exports.config = qa_config;