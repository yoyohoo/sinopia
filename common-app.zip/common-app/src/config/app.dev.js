var dev_config = {
    "ENV": "dev",
    "REST_URL": "http://10.25.1.111"
}
exports.config = dev_config;