import { createApp } from 'vue';
import router from './router/index';
import store from './store/index';

import App from './App.vue';
import '@/assets/common.css';

import { getEnvConfig } from '@/service/config.service';

const app = createApp(App);
app.use(router);
app.use(store);

app.config.globalProperties.customProperty = getEnvConfig;
app.config.globalProperties.$store = store;

app.mount('#app');

console.log('servcie: ', getEnvConfig());
