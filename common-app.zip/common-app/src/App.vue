<template>
  <div id="my-app">
    <router-link to="/"> Home</router-link>
    <router-link to="/contact"> Contact </router-link>
    <router-view />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
#my-app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
  transform: rotate(0deg);
}

#my-app > div {
  margin: 10px auto;
}
</style>