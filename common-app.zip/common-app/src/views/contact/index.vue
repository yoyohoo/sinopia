<template>
  <div>
    <h1>webfont 字体预览</h1>
    <p class="web-font">英雄不问出路，流氓不看岁数</p>

    <div>
      <input type="text" />
    </div>
  </div>
</template>
<script src="./index.js"></script>
<style src="./index.css"></style>