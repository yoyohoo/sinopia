export default {
	name: "contact",
};