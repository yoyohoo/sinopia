import { Button } from "vant";
import { useStore } from 'vuex';

export default {
	name: "home",
	setup() {
		const store = useStore();
		return {
			store
		}
	},
	components: {
		[Button.name]: Button,
	},
	mounted() {
		console.log(this.$store.state.storeMsg)
	}
};