<template>
  <div>
    <div>
      <div class="hd hd-1"></div>
      <div class="hd hd-2"></div>
      <div class="hd hd-3"></div>
    </div>

    <div>
      <div class="no no-0"></div>
      <div class="no no-1"></div>
      <div class="no no-2"></div>
    </div>

    <div class="app">
      <h1>store: {{ store.state.storeMsg }}</h1>

      <van-button type="primary" @click="include">Vant 按钮</van-button>
    </div>
  </div>
</template>
<script src="./index.js"></script>
<style src="./index.css"></style>